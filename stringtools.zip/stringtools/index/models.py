from django.db import models

# Create your models here.
class Filesgroup(models.Model):
    #ID = models.AutoField('ID')
    name = models.CharField('文件名',max_length=200)
    path = models.CharField('文件路径',max_length=200)
    url = models.CharField('文件url路径',max_length=200)
    clock = models.DateTimeField('文件上传时间',)
    #def __str__(self): return self.name  # 给模型增加 __str__() 方法是很重要的，这不仅仅能给你在命令行里使用带来方便，Django 自动生成的 admin 里也使用这个方法来表示对象。

class Referrer(models.Model):
    #ID = models.AutoField('ID')
    name = models.CharField('IP',max_length=200)
    clock = models.DateTimeField('访问时间',)