from django.http import HttpResponseRedirect
from django.shortcuts import render
# Create your views here.
from django.http import HttpResponse
from collections import defaultdict
import pandas as pd
import csv
import datetime
from .models import *
import os
from django.utils.http import urlquote
###########################################################
#这是主页
def home(request):
    title='home_page'
    return render(request,'index/home.html',locals())



#############################################################
#这是文件合并页面
def files2one(request):
    title='多文件合并'
    return render(request,'index/files2one.html',locals())




###############################################################################
#这是文件指定内容提取页面
import io
from django.http import FileResponse

def fun(content,keys,position):
    d = defaultdict(list)
    head = content[0]
    for i in content[1:]:
        if i != '':
            d[i.split('\t')[position]].append(i.strip())
    results=[head]
    for i in keys:
        if d.get(i,'') != '':
            results.append('\t'.join(d.get(i)))
        else:
            results.append(i)
    return '\n'.join(results)

def extract(request):
    title='关键字提取'
    if request.method == 'GET':
        return render(request,'index/extract.html',locals())
    if request.method=='POST':
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment;filename="output.txt"'
        content=request.POST.get('content').split('\r\n')
        keys = request.POST.get('keys').split('\r\n')
        position = int(request.POST.get('position'))-1
        results=fun(content,keys,position)
        response.write(results)
        return response
####################################################################
def merge(request):
    title='文件聚合'
    if request.method == 'GET':
        return render(request,'index/file_merge.html',locals())
    if request.method == 'POST':
        content1 = request.POST.get('content1')
        data1=pd.DataFrame([i.strip().split('\t') for i in content1.split('\r\n')[1:]],\
                           columns=content1.split('\r\n')[0].split('\t'))
        content2 = request.POST.get('content2')
        data2 = pd.DataFrame([i.strip().split('\t') for i in content2.split('\r\n')[1:]], \
                             columns=content2.split('\r\n')[0].split('\t'))
        left_on = request.POST.get('left_on').split(',')
        right_on = request.POST.get('right_on').split(',')

        result=pd.merge(data1,data2,left_on=left_on,right_on=right_on,how='outer')
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment;filename=output.txt'
        writer = csv.writer(response)
        writer.writerow(result.columns)
        for index,row in result.iterrows():
            writer.writerow(row)
        return response

########################################################
#残缺的耳号找到可能的完整耳号

def fun2(full,half):
    results=['部分耳号\t可能的完整耳号']
    for i in half:
        if i!='':
            i=i.strip()
            r = []
            for j in full:
                j=j.strip()
                if j.endswith(i):
                    r.append(j)
            results.append(i+'\t'+','.join(r))
    return '\n'.join(results)

def search_full(request):
    title='查找完整耳号'
    if request.method == 'GET':
        return render(request,'index/search_full.html',locals())
    if request.method == 'POST':
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment;filename="output.txt"'
        full = request.POST.get('full').split('\r\n')
        half = request.POST.get('half').split('\r\n')
        results = fun2(full, half)
        response.write(results)
        return response

####################################################
#残缺的耳号去找完整耳号的附属信息
def fun3(full,half,position):
    d = defaultdict(list)
    head = full[0]
    results = ['残缺耳号\t'+head]  #保存表头
    for i in full[1:]:
        if i!='':
            d[i.split('\t')[position]].append(i.strip())

    for i in half:
        if i!='':
            r=[]
            for j in d.keys():
                if j.endswith(i.strip()):
                    r.append(','.join(d.get(j)))
            results.append(i+'\t'+','.join(r))
    return '\n'.join(results)

def search_info(request):
    title='残缺耳号查找完整耳号的附属信息'
    if request.method == 'GET':
        return render(request,'index/search_info.html',locals())
    if request.method == 'POST':
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment;filename="output.txt"'
        full = request.POST.get('full').split('\r\n')
        half = request.POST.get('half').split('\r\n')
        position = int(request.POST.get('position')) - 1
        results = fun3(full, half,position)
        response.write(results)
        return response

######################################################
#元素个数计数
def Count(request):
    title = '残缺耳号查找完整耳号的附属信息'
    if request.method == 'GET':
        return render(request, 'index/Count.html', locals())
    if request.method == 'POST':
        response = HttpResponse(content_type='text/plain')
        response['Content-Disposition'] = 'attachment;filename="output.txt"'
        full = request.POST.get('full').split('\r\n')
        results=pd.Series(full).value_counts().to_dict()
        response.write('元素\t个数\n')
        for i in results:
            if i!='':
                response.write(str(i)+'\t'+str(results.get(i))+'\n')
        return response

#简易网盘
def get_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]#所以这里是真实的ip
    else:
        ip = request.META.get('REMOTE_ADDR')#这里获得代理ip
    return ip

def yunpan(request):
    title = '简易网盘,上传和下载文件'
    if request.method == 'GET':
        head=['ID','文件名','文件位置','上传时间','操作']
        results=Filesgroup.objects.all()
        ip=get_ip(request)
        time = datetime.datetime.now()
        logs=Referrer()
        logs.name=ip
        logs.clock=time
        logs.save()
        return render(request, 'index/Save.html', locals())
    if request.method == 'POST':
        time=datetime.datetime.now()
        filename = request.FILES.get("file").name  # 获取文件名
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        filepath=os.path.join(BASE_DIR,filename)
        file_url = os.path.join('http://114.116.41.188',filename)
        b = Filesgroup(name=filename, path=filepath,url=file_url,clock=time)
        b.save()  # 保存
        with open(filepath,'wb') as f:
            for i in request.FILES.get("file").chunks():
                f.write(i)
            return HttpResponseRedirect('/Save.html')


# 下载文件
def download(request):
    id=request.GET.get('id')
    file_info = Filesgroup.objects.get(id=id)
    print('下载的文件名：' + file_info.name)
    file = open(file_info.path, 'rb')
    response = FileResponse(file)
    response['Content-Disposition'] = 'attachment;filename="%s"' % urlquote(file_info.name)
    return response


# 删除文件
def delete(request):
    id = request.GET.get('id')
    file_info = Filesgroup.objects.get(id=id)
    try:
        os.remove(file_info.path)
    except:
        pass
    file_info.delete()
    file_infos = Filesgroup.objects.all()
    return HttpResponseRedirect('/Save.html')

