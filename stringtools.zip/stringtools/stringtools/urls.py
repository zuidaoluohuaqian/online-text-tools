"""stringtools URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from index import views as index_views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index_views.home, name='home'),
    path(r'files2one.html', index_views.files2one, name='files2one'),
    path(r'extract.html', index_views.extract, name='extract'),
    path(r'file_merge.html', index_views.merge, name='merge'),
    path(r'search_full.html', index_views.search_full, name='search_full'),
    path(r'search_info.html', index_views.search_info, name='search_info'),
    path(r'Count.html', index_views.Count, name='Count'),
    path(r'Save.html', index_views.yunpan, name='yunpan'),
    path(r'download', index_views.download, name='download'),  # 下载
    path(r"delete", index_views.delete, name='delete'),  # 删除
]
